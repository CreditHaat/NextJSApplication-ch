import React from "react";
import MainComponent from "../../components/SmartCoin/MainComponent";

const page = () => {
  return <MainComponent />;
};

export default page;
