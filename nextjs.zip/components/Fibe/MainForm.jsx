import React from 'react'
import Form from './Form'

const MainForm = () => {
  return (
    <>
        <Form/>
    </>
  )
}

export default MainForm