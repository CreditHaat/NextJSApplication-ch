// import HomePage from '@/components/HomePage'
// import MainComponent from '@components/NewPersonalLoan/MainComponent'
// import HomePage from '@/components/HomePage';
// import HomePage from '@'
// import HomePage from '@/components/HomePage'
import HomePage from '../components/HomePage'


const page = () => {
  return (
    <>
        {/* <HomePage/> */}
        <HomePage/>
        {/* <MainComponent/> */}
    </>
  )
}

export default page
