import React from 'react'

const Header = () => (
  <header>
    <h1 className="header">Embla Carousel Generator React</h1>
  </header>
)

export default Header
