import React from 'react'

const temporary = () => {
  return (
    <div>
      HIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
    </div>
  )
}

export default temporary
