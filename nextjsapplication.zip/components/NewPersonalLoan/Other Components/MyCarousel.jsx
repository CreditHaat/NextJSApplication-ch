// import 'react-responsive-carousel/lib/styles/carousel.min.css'; // Import carousel styles
// import Image from 'next/image'; // Next.js Image component for optimized image loading
// import NewFormPageImage from '../NewPersonalLoanImages/NewFormPageImage.png';
// import NewFormPageImage2 from '../NewPersonalLoanImages/FormPageImage2.png';
// import Carousel from 'react-responsive-carousel';
// import NewFormPageImage3 from '../NewPersonalLoanImages/FormPageImage3.png';
// import { Carousel } from 'react-responsive-carousel';

const MyCarousel = () => {
  return (
    <div>
      Hii
    </div>
  )
}

export default MyCarousel


// import 'react-responsive-carousel/lib/styles/carousel.min.css'; // Import carousel styles
// import Image from 'next/image'; // Next.js Image component for optimized image loading
// import NewFormPageImage from '../NewPersonalLoanImages/NewFormPageImage.png';
// import NewFormPageImage2 from '../NewPersonalLoanImages/FormPageImage2.png';
// import NewFormPageImage3 from '../NewPersonalLoanImages/FormPageImage3.png';
// import { Carousel } from 'react-responsive-carousel';

// const MyCarousel = () => {

//   //   const images = [
//   //     NewFormPageImage,
//   //     NewFormPageImage2,
//   //     NewFormPageImage3,
//   // ];

//   return (
//     <>
//       <Carousel infiniteLoop autoPlay showThumbs={false}>
//         {images.map((image, index) => (
//           <div key={index}>
//             <Image src={image} alt={`Image ${index}`} width={500} height={500} />
            
//           </div>
//         ))}
//       </Carousel>
//     </>
//   );
// };

// export default MyCarousel;