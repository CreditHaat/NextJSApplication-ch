
// import Form3 from "@Components/NewPersonalLoan/Other Components/Form3";
// import MainComponent3 from "@components/NewPersonalLoan/MainComponent3"
// import MainComponent3 from "../NewPersonalLoan/Components/MainComponent3";
// import MainComponent3 from "./components/NewPersonalLoan/MainComponent3";
import MainComponent3 from "../../components/NewPersonalLoan/MainComponent3"

const personalloan = () => {
  return (
    <>
     
      {/* <Form3/> */}
      <MainComponent3/>
    </>
  )
}

export default personalloan
