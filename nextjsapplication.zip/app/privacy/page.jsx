import React from 'react'
import Privacy from '../../components/TermsCondition/PrivacyPolicy';

const page = () => {
  return (
    <div>
      <Privacy/>
    </div>
  )
}

export default page
