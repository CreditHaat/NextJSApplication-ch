import React from 'react'
import Fibe from "../../components/Fibe/MainComponent";


const page = () => {
  return (
    <div>
      <Fibe/>
    </div>
  )
}

export default page
