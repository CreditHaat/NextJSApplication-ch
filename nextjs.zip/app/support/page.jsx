import React from 'react'
import Support from '../../components/TermsCondition/Support'

const page = () => {
  return (
    <div>
      <Support/>
    </div>
  )
}

export default page
