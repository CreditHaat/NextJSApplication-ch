import React from 'react'
import Aquisition from '../../components/Acqusition/AcquisitionPartner';
import Footer from '../../components/Footer'
import NavBar from '../../components/Header1/NavBar'

const page = () => {
  return (
    <div>
        <NavBar/>
      <Aquisition/>
      <Footer/>
    </div>
  )
}

export default page
