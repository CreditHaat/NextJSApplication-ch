import BLApplyPageFirst from "../../components/BLApplyPrime/BLApplyPageFirst"
import BLApplyLenders from "../../components/BLApplyPrime/BLApplyLenders";
import ForSelfEmployed from "../../components/BLApplyPrime/ForSelfEmployed";
import ForSalaried from "../../components/BLApplyPrime/ForSalaried";


const page = () => {
  return (
    <>
    <div style={{fontFamily:"sans-serif"}}>
     
      {/* <Form3/> */}
      <BLApplyPageFirst/>
    </div>
      {/* <BLApplyLenders/> */}
    {/* <ForSelfEmployed/> */}
{/* <ForSalaried/> */}
    </>
  )
}

export default page
