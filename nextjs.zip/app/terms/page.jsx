import React from 'react'
import Terms from '../../components/TermsCondition/TermsCondition';

const page = () => {
  return (
    <div>
      <Terms/>
    </div>
  )
}

export default page
