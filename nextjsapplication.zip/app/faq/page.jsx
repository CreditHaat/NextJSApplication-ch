import React from 'react'
import FAQ from '../../components/Homepage/FAQ'
import Footer from '../../components/Footer'
import NavBar from '../../components/Header1/NavBar'
const page = () => {
  return (
    <div>
        <NavBar/>
      <FAQ/>
      <Footer/>
    </div>
  )
}

export default page
